import assert from "node:assert/strict";
import crypto from "node:crypto";
import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";
import { promisify } from "node:util";
const root = process.argv[2];
const load = file => import(pathToFileURL(`${root}/${file}`));
const require = createRequire(`${root}/package.json`);
const pg = require("pg");
const mapping = await load("src/shared/persistence/store-mapping.mjs");
const { initializePostgresSchema } = await load("src/shared/persistence/postgres-migration.mjs");
const { writeStoreObjects } = await load("src/shared/persistence/postgres-objects.mjs");
const { createAccountUnitOfWork } = await load(".build/typescript/backend/shared/persistence/account-unit-of-work.mjs");
const { createThoughtRecordRepository } = await load(".build/typescript/backend/shared/persistence/thought-record-repository.mjs");
const { createThoughtService } = await load("src/modules/thoughts/index.mjs");
const bin = process.env.PG_TEST_BIN || "/Users/bytedance/Documents/Personal/forNow/data/pg-integration-tools/postgresql-16.14/bin";
const temporary = await fs.mkdtemp(path.join(os.tmpdir(), "fornow-review-source-pg-"));
const cluster = path.join(temporary, "cluster");
const password = crypto.randomBytes(24).toString("hex");
const passwordFile = path.join(temporary, "password");
const env = { ...process.env, LC_ALL: "C", LANG: "C", TZ: "UTC",
  DYLD_LIBRARY_PATH: path.resolve(bin, "../lib") };
const exec = promisify(execFile);
const command = (name, args) => exec(path.join(bin, name), args, { env, timeout: 30000 });
const port = await new Promise(resolve => {
  const server = net.createServer();
  server.listen(0, "127.0.0.1", () => {
    const value = server.address().port;
    server.close(() => resolve(value));
  });
});
let started = false, client;
try {
  await fs.writeFile(passwordFile, password, { mode: 0o600 });
  await command("initdb", ["-D", cluster, "-U", "postgres", "-A", "scram-sha-256",
    "--pwfile", passwordFile, "--locale=C", "--encoding=UTF8"]);
  await fs.appendFile(path.join(cluster, "postgresql.conf"),
    `\nlisten_addresses='127.0.0.1'\nport=${port}\nunix_socket_directories=''\n`);
  await command("pg_ctl", ["-D", cluster, "-l", path.join(temporary, "postgres.log"), "-w", "start"]);
  started = true;
  client = new pg.Client({ host: "127.0.0.1", port, user: "postgres", password, database: "postgres" });
  await client.connect();
  await initializePostgresSchema(client);
  await client.query("CREATE ROLE audit_data NOSUPERUSER NOBYPASSRLS");
  await client.query("GRANT USAGE ON SCHEMA for_now TO audit_data");
  await client.query("GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA for_now TO audit_data");
  const accountId = "audit-source-account";
  await client.query("INSERT INTO for_now.accounts(account_id) VALUES ($1)", [accountId]);
  const store = {
    captures: [{ id: "capture-a", content: "来源随记", version: 1 }],
    thoughts: [{ id: "root-a", type: "question", content: "原问题", version: 1,
      sourceRef: { type: "capture", id: "capture-a", version: 1 }, remarks: [] }]
  };
  await writeStoreObjects(client, mapping.mapStoreObjects(accountId, store));
  const transaction = async operation => {
    await client.query("BEGIN");
    try {
      await client.query("SET LOCAL ROLE audit_data");
      await client.query("SELECT set_config('app.account_id',$1,true)", [accountId]);
      await client.query("SELECT account_id FROM for_now.accounts WHERE account_id=$1 FOR UPDATE", [accountId]);
      const result = await operation(client, accountId);
      await client.query("COMMIT");
      return result;
    } catch (error) { await client.query("ROLLBACK"); throw error; }
  };
  const uow = createAccountUnitOfWork({ transaction });
  const graph = createThoughtRecordRepository(mapping);
  const service = createThoughtService({
    repository: {}, createId: () => "root-b", now: () => "2026-10-19T00:00:00.000Z",
    recordVersion: value => Number(value) || 1,
    reanchorAnnotations: () => {}, eventTimeFields: () => ({})
  });
  const readSource = async () => (await client.query(
    "SELECT target_key,resolution FROM for_now.store_relations WHERE account_id=$1 AND relation='source'",
    [accountId])).rows;
  const before = await readSource();
  assert.equal(before[0].resolution, "live");
  await uow.run({ commandId: "audit.source.edit" }, async ports => {
    const closure = await graph.readThoughtDeleteClosure(ports, "root-a");
    const result = service.updateChainInStore(closure.store, {
      id: "root-a", questionText: "修改后的问题", expectedVersion: 1, tags: []
    });
    assert.equal(result.value.id, "root-a");
    await graph.persistMappedClosure(ports, accountId, closure.rows, closure.store);
    ports.addChange({ entityType: "thought", entityId: "root-a", version: 2,
      operation: "update", changedFields: ["content"], scopeKeys: ["thought:list", "thought:root-a"] });
  });
  const after = await readSource();
  assert.deepEqual(after, [{ target_key: null, resolution: "historical" }]);
  const next = await uow.run({ commandId: "audit.source.lookup" },
    ports => graph.createThoughtStoreClosure(ports, { sourceRef: store.thoughts[0].sourceRef }));
  assert.equal(next.value.store.captures.length, 1);
  assert.equal(next.value.store.thoughts.length, 0);
  const repeat = service.createChainInStore(next.value.store, {
    questionText: "再次从同一随记转换", clientRequestId: "second-conversion", tags: [],
    sourceRef: store.thoughts[0].sourceRef
  });
  assert.ok(repeat.items);
  console.log(JSON.stringify({ probe: "capture-source-reference-loss-postgres",
    revision: "f01f0f1", database: "fresh isolated PostgreSQL 16.14",
    role: "NOSUPERUSER NOBYPASSRLS", before, after,
    sourceStillExists: true, conversionLookupExistingRoots: 0, secondConversionAccepted: true }, null, 2));
} finally {
  await client?.end();
  if (started) await command("pg_ctl", ["-D", cluster, "-w", "-m", "immediate", "stop"]);
  await fs.rm(temporary, { recursive: true, force: true });
}
