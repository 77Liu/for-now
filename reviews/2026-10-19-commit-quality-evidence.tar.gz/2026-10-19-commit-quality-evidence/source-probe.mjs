import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
const root = process.argv[2];
const load = file => import(pathToFileURL(`${root}/${file}`));
const mapping = await load("src/shared/persistence/store-mapping.mjs");
const { createThoughtRecordRepository } = await load(".build/typescript/backend/shared/persistence/thought-record-repository.mjs");
const { createThoughtService } = await load("src/modules/thoughts/index.mjs");
const graph = createThoughtRecordRepository(mapping);
const store = {
  captures: [{ id: "capture-a", content: "来源随记", version: 1 }],
  thoughts: [{ id: "root-a", type: "question", content: "原问题", version: 1,
    sourceRef: { type: "capture", id: "capture-a", version: 1 }, remarks: [] }]
};
const mapped = mapping.mapStoreObjects("audit-account", store);
const rows = new Map(mapped.objects.map(row => [row.objectKey, structuredClone(row)]));
let relations = structuredClone(mapped.relations);
const relation = () => relations.find(row => row.objectKey === '["thoughts","root-a"]' && row.relation === "source");
const ports = {
  objects: {
    async find(key) { return rows.get(key) || null; },
    async findMany(keys) { return keys.flatMap(key => rows.has(key) ? [rows.get(key)] : []); },
    async update(row) { rows.set(row.objectKey, structuredClone(row)); return true; },
    async ensureCollection() {}
  },
  relations: {
    async removeForObject(key) { relations = relations.filter(row => row.objectKey !== key); },
    async insert(row) { relations.push(structuredClone(row)); },
    async findSources(keys, options) {
      return relations.filter(row => keys.includes(row.targetKey)
        && row.relation === options.relation
        && rows.get(row.objectKey).collection === options.sourceCollection).map(row => row.objectKey);
    }
  },
  attachments: { async removeForObject() {}, async insert() {} }
};
const before = structuredClone(relation());
assert.equal(before.resolution, "live");
const localRows = mapped.objects.filter(row => row.collection === "thoughts");
const localStore = graph.rebuildRecordCollections(localRows, ["thoughts"]);
const service = createThoughtService({
  repository: {}, createId: () => "root-b", now: () => "2026-10-19T00:00:00.000Z",
  recordVersion: value => Number(value) || 1,
  reanchorAnnotations: () => {}, eventTimeFields: () => ({})
});
const update = service.updateChainInStore(localStore, {
  id: "root-a", questionText: "修改后的问题", tags: [], expectedVersion: 1
});
assert.equal(update.value.id, "root-a");
await graph.persistMappedClosure(ports, "audit-account", localRows, localStore);
assert.ok(rows.has('["captures","capture-a"]'));
assert.equal(relation().resolution, "historical");
assert.equal(relation().targetKey, null);
const next = await graph.createThoughtStoreClosure(ports, { sourceRef: store.thoughts[0].sourceRef });
assert.equal(next.store.thoughts.length, 0);
const repeat = service.createChainInStore(next.store, {
  questionText: "第二次从相同随记转换", clientRequestId: "second-conversion", tags: [],
  sourceRef: store.thoughts[0].sourceRef
});
assert.equal(repeat.sourceConflict, undefined);
assert.equal(repeat.items[0].id, "root-b");
console.log(JSON.stringify({
  probe: "capture-source-reference-loss", revision: "f01f0f1",
  level: "real mapper/repository/business functions with in-memory SQL port semantics",
  sourceStillExists: true, before, after: relation(),
  conversionLookupExistingRoots: 0, secondConversionAccepted: true
}, null, 2));
