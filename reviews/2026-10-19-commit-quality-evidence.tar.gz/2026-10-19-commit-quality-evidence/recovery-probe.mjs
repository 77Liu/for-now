import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
const root = process.argv[2];
const load = file => import(pathToFileURL(`${root}/${file}`));
const { createBackgroundAi } = await load("src/app/background-ai.mjs");
const { createTaskLifecycle } = await load("src/modules/tasks/index.mjs");
const { createTaskTransitionCommands } = await load(".build/typescript/backend/app/record-commands/task-transitions.mjs");
const mapping = await load("src/shared/persistence/store-mapping.mjs");
async function measure(count, unrelatedCount) {
  const store = {
    thoughts: [{ id: "root-a", type: "question", content: "原文", version: 1 }],
    captures: Array.from({ length: unrelatedCount }, (_, index) => ({
      id: `unrelated-${index}`, content: "无关历史".repeat(100), version: 1
    })),
    aiTasks: Array.from({ length: count }, (_, index) => ({
      id: `task-${index}`, kind: "thoughtAnswer", status: "queued", resourceType: "thought",
      targetId: "root-a", inputHash: "valid-hash", inputVersion: 1, version: 1, attempt: 1
    })),
    notifications: Array.from({ length: count }, (_, index) => ({
      id: `notice-${index}`, taskId: `task-${index}`, resourceType: "thought", targetId: "root-a",
      status: "queued", version: 1
    }))
  };
  const mapped = mapping.mapStoreObjects("audit-account", store);
  const rows = new Map(mapped.objects.map(row => [row.objectKey, row]));
  let reads = 0, bytes = 0, transitions = 0, dispatches = 0;
  const ports = {
    objects: {
      async find(key) { return rows.get(key); },
      async findMany(keys) { return keys.map(key => rows.get(key)); },
      async update() { throw new Error("Queued recovery should not write"); }
    },
    relations: {
      async findSources(keys, { relation }) {
        return mapped.relations.filter(row => keys.includes(row.targetKey) && row.relation === relation)
          .map(row => row.objectKey);
      }
    },
    addChange() {}
  };
  const uow = {
    async readRevision() { return "1"; },
    async run(options, operation) {
      transitions++;
      return { value: await operation(ports) };
    }
  };
  const transition = createTaskTransitionCommands({ unitOfWork: uow, mapping });
  const repository = {
    accountUnitOfWork: uow,
    async read() {
      reads++;
      bytes += Buffer.byteLength(JSON.stringify(store));
      return structuredClone(store);
    },
    async update() { throw new Error("Unexpected legacy update"); }
  };
  const background = createBackgroundAi({
    repository, contextKey: () => "audit-account",
    tasks: createTaskLifecycle({ createId: () => "unused", now: () => new Date().toISOString(), hash: value => value }),
    notifications: {}, targets: {}, generate: async () => { throw new Error("No model"); },
    dispatch: () => { dispatches++; }, onError: error => { throw error; },
    recordCommands: {
      enabled: name => name === "task.status",
      tasks: { cancel: async () => {}, bindInput: async () => {} },
      transitions: transition
    }
  });
  await background.resume();
  assert.equal(reads, count + 2);
  assert.equal(transitions, count);
  assert.equal(dispatches, count);
  return { pendingTasks: count, unrelatedCaptures: unrelatedCount, wholeAccountReads: reads,
    wholeAccountSnapshotBytes: bytes, recoveryTransactions: transitions };
}
console.log(JSON.stringify({
  probe: "task-recovery-whole-account-read-amplification",
  revision: "f01f0f1",
  level: "real background resume and transition functions; instrumented repository, no PostgreSQL timing claim",
  results: [await measure(10, 100), await measure(100, 100), await measure(100, 1000)]
}, null, 2));
